
/* St Andrews Society Hub — Demo App (no backend, localStorage only)
 * Features:
 * - Follow societies
 * - Auto-add all events from followed societies to "My Timetable"
 * - Manually add individual events (from any society) to your calendar
 * - RSVP checkboxes persist
 * - Simple profile (name, age, interests)
 */

(function () {
  const LS_KEYS = {
    profile: "sta.profile",
    follows: "sta.follows",
    selectedEventIds: "sta.selectedEventIds",
    rsvps: "sta.rsvps"
  };

  // --- Demo data ------------------------------------------------------------
  // Times are local (no TZ) and in ISO 8601 "YYYY-MM-DDTHH:mm"
  const societies = [
    {
      id: "datasci",
      name: "Data Science Society",
      similarity: 95,
      blurb: "Hands-on coding nights, real-world data hackathons.",
      events: [
        { id: "e_ds_analytics101", title: "Intro to Analytics", start: "2025-11-05T17:00", location: "Computer Lab 3" },
        { id: "e_ds_hack",        title: "Mini Data Hack",     start: "2025-11-12T18:00", location: "Data Hub" }
      ]
    },
    {
      id: "finance",
      name: "Finance Society",
      similarity: 94,
      blurb: "Market insights, networking with industry leaders.",
      events: [
        { id: "e_fin_talk1", title: "Markets Outlook", start: "2025-11-06T18:00", location: "Union Hall" },
        { id: "e_fin_game",  title: "Trading Game",    start: "2025-11-14T17:30", location: "Business School 102" }
      ]
    },
    {
      id: "consulting",
      name: "Consulting Society",
      similarity: 93,
      blurb: "Real case workshops, strategy challenges.",
      events: [
        { id: "e_cons_case",  title: "Case Interview 101", start: "2025-11-07T16:30", location: "Business Room 204" },
        { id: "e_cons_board", title: "Boardroom Sprint",   start: "2025-11-21T16:00", location: "Exec Suite" }
      ]
    },
    {
      id: "econ",
      name: "Economics Forum",
      similarity: 91,
      blurb: "Global policy debates, top economist talks.",
      events: [
        { id: "e_econ_policy", title: "Policy Debate: AI & GDP", start: "2025-11-08T14:00", location: "Econ Building 301" }
      ]
    },
    {
      id: "ai",
      name: "Artificial Intelligence Club",
      similarity: 90,
      blurb: "Build-your-own AI, ethics meetups, coding jams.",
      events: [
        { id: "e_ai_build", title: "Build a Chatbot", start: "2025-11-03T18:00", location: "Tech Building" }
      ]
    },
    {
      id: "sports-analytics",
      name: "Sports Analytics Society",
      similarity: 80,
      blurb: "Data-driven game nights, analytics bootcamps.",
      events: [
        { id: "e_sa_boot", title: "Analytics Bootcamp", start: "2025-11-09T15:00", location: "Data Hub" }
      ]
    },
    {
      id: "italian",
      name: "Italian Language Club",
      similarity: 82,
      blurb: "Espresso chats, Italian film & food nights.",
      events: [
        { id: "e_it_film", title: "Italian Film Night", start: "2025-11-10T17:00", location: "Arts Building" }
      ]
    }
  ];

  // --- LocalStorage helpers -------------------------------------------------
  function readJSON(key, fallback) {
    try { return JSON.parse(localStorage.getItem(key)) ?? fallback; }
    catch { return fallback; }
  }

  function writeJSON(key, value) { localStorage.setItem(key, JSON.stringify(value)); }

  const state = {
    get profile() { return readJSON(LS_KEYS.profile, null); },
    set profile(p) { writeJSON(LS_KEYS.profile, p); },

    get follows() { return new Set(readJSON(LS_KEYS.follows, [])); },
    set follows(set) { writeJSON(LS_KEYS.follows, Array.from(set)); },

    get selectedEventIds() { return new Set(readJSON(LS_KEYS.selectedEventIds, [])); },
    set selectedEventIds(set) { writeJSON(LS_KEYS.selectedEventIds, Array.from(set)); },

    get rsvps() { return readJSON(LS_KEYS.rsvps, {}); },
    set rsvps(obj) { writeJSON(LS_KEYS.rsvps, obj); }
  };

  function byId(id) { return document.getElementById(id); }

function attachClearDataHandlers() {
  const btns = Array.from(document.querySelectorAll('#clear-data'));
  if (!btns.length) return;
  for (const b of btns) {
    b.addEventListener('click', () => {
      try {
        localStorage.removeItem(LS_KEYS.profile);
        localStorage.removeItem(LS_KEYS.follows);
        localStorage.removeItem(LS_KEYS.selectedEventIds);
        localStorage.removeItem(LS_KEYS.rsvps);
      } catch {}
      // Force a full reload so all pages reset consistently
      window.location.reload();
    });
  }
}


  // Utility: find a society by id; event lookup
  function getSociety(sid) { return societies.find(s => s.id === sid); }
  function getEventById(eid) {
    for (const s of societies) {
      const ev = s.events.find(e => e.id === eid);
      if (ev) return { society: s, event: ev };
    }
    return null;
  }

  // Combine events from followed societies and individually selected ones
  function computeMyEvents() {
    const all = new Map(); // eventId -> {society,event,source}
    // From follows
    for (const sid of state.follows) {
      const s = getSociety(sid);
      if (!s) continue;
      for (const ev of s.events) {
        all.set(ev.id, { society: s, event: ev, source: "follow" });
      }
    }
    // From manual selections
    for (const eid of state.selectedEventIds) {
      const found = getEventById(eid);
      if (found) {
        const existing = all.get(eid);
        all.set(eid, { ...found, source: existing?.source ?? "manual" });
      }
    }
    // Sort by time
    return Array.from(all.values()).sort((a,b) => a.event.start.localeCompare(b.event.start));
  }

  // RSVP helpers
  function setRsvp(eventId, attending) {
    const r = state.rsvps;
    r[eventId] = !!attending;
    state.rsvps = r;
  }
  function getRsvp(eventId) {
    const r = state.rsvps;
    return !!r[eventId];
  }

  // --- Page initialisers ----------------------------------------------------
  function initProfilePage() {
    const nameInput = document.querySelector('input[name="name"]');
    const ageInput = document.querySelector('input[name="age"]');
    const form = document.querySelector("form.profile");
    const interestsInputs = Array.from(document.querySelectorAll('input[name="interests"]'));

    // Prefill if present
    const p = state.profile;
    if (p) {
      nameInput.value = p.name || "";
      ageInput.value = p.age || "";
      interestsInputs.forEach(i => i.checked = p.interests?.includes(i.value));
    }

    form.addEventListener("submit", (e) => {
      e.preventDefault();
      const interests = interestsInputs.filter(i => i.checked).map(i => i.value);
      state.profile = {
        name: nameInput.value.trim(),
        age: ageInput.value ? Number(ageInput.value) : null,
        interests
      };
      // Navigate to For You after save
      window.location.href = "foryou.html";
    });
  }

  function makeSocietyCard(s) {
    const follows = state.follows;
    const isFollowing = follows.has(s.id);
    const next = s.events.slice().sort((a,b)=>a.start.localeCompare(b.start))[0];

    const article = document.createElement("article");
    article.className = "society-card";

    const h2 = document.createElement("h2");
    h2.textContent = s.name;

    const sim = document.createElement("p");
    sim.className = "muted";
    sim.textContent = `Similarity: ${s.similarity}%`;

    const blurb = document.createElement("p");
    blurb.textContent = s.blurb;

    const nextP = document.createElement("p");
    nextP.innerHTML = next ? `<strong>Next Event:</strong> ${formatWhen(next.start)}, ${next.location}` : "<em>No upcoming events</em>";

    const actions = document.createElement("div");
    actions.style.marginTop = ".5rem";

    const followBtn = document.createElement("button");
    followBtn.className = "btn";
    followBtn.textContent = isFollowing ? "Following ✓" : "Follow";
    followBtn.setAttribute("aria-pressed", isFollowing ? "true" : "false");
    followBtn.addEventListener("click", () => {
      const set = state.follows;
      if (set.has(s.id)) set.delete(s.id); else set.add(s.id);
      state.follows = set;
      // re-render this card state
      followBtn.textContent = set.has(s.id) ? "Following ✓" : "Follow";
      followBtn.setAttribute("aria-pressed", set.has(s.id) ? "true" : "false");

    });

    actions.appendChild(followBtn);

    const viewLink = document.createElement('a');
    viewLink.href = `events.html?society=${encodeURIComponent(s.id)}`;
    viewLink.className = 'btn linkish';
    viewLink.style.marginLeft = '.5rem';
    viewLink.textContent = 'View events →';
    actions.appendChild(viewLink);

    article.append(h2, sim, blurb, nextP, actions);
    return article;
  }

  function isEventInCalendar(eventId) {
    const mine = computeMyEvents().map(x => x.event.id);
    return mine.includes(eventId);
  }

  function initForYouPage() {
    const container = document.querySelector(".society-list");
    container.innerHTML = ""; // clear server markup
    // Optional interest-based sort (profile interests matching)
    const profile = state.profile;
    let list = societies.slice();
    if (profile?.interests?.length) {
      list.sort((a,b) => {
        const score = s => {
          const name = s.name.toLowerCase();
          return profile.interests.reduce((acc, i) => acc + (name.includes(i.toLowerCase()) ? 1 : 0), 0);
        };
        return score(b) - score(a) || (b.similarity - a.similarity);
      });
    } else {
      list.sort((a,b) => b.similarity - a.similarity);
    }

    for (const s of list) {
      container.appendChild(makeSocietyCard(s));
    }

    // Show demo banner
    addDemoBanner();
  }

  function initTimetablePage() {
  let currentWeek = startOfWeek(new Date());

  const tabs = document.createElement("div");
  tabs.className = "toolbar";
  const prevBtn = document.createElement("button");
  prevBtn.className = "btn";
  prevBtn.textContent = "← Previous week";
  const nextBtn = document.createElement("button");
  nextBtn.className = "btn";
  nextBtn.textContent = "Next week →";
  const weekLabel = document.createElement("span");
  weekLabel.className = "muted";
  weekLabel.style.marginLeft = ".5rem";

  function updateToolbar() {
    const end = addDays(currentWeek, 6);
    const opts = { day:"numeric", month:"short" };
    weekLabel.textContent = `Week: ${currentWeek.toLocaleDateString(undefined, opts)} – ${end.toLocaleDateString(undefined, opts)}`;
  }

  prevBtn.addEventListener("click", () => { currentWeek = addDays(currentWeek, -7); renderGrid(); updateToolbar(); });
  nextBtn.addEventListener("click", () => { currentWeek = addDays(currentWeek, 7); renderGrid(); updateToolbar(); });

  tabs.append(prevBtn, nextBtn, weekLabel);
  document.querySelector("main .container, main.container")?.prepend?.(tabs);

  const container = document.querySelector(".calendar");
  const emptyMsg = byId("empty-msg");

  function renderGrid() {
    container.innerHTML = "";

    const items = computeMyEvents();
    if (!items.length) {
      if (emptyMsg) emptyMsg.style.display = "block";
      return;
    }
    if (emptyMsg) emptyMsg.style.display = "none";

    // Build grid skeleton
    const wrapper = document.createElement("div");
    wrapper.className = "grid-wrapper";

    const grid = document.createElement("div");
    grid.className = "grid";

    // Header row: first cell empty then Mon..Sun
    const days = ["Mon","Tue","Wed","Thu","Fri","Sat","Sun"];
    const headerRow = document.createElement("div");
    headerRow.className = "grid-row grid-header";
    headerRow.appendChild(document.createElement("div")); // top-left empty
    for (let i=0;i<days.length;i++) {
      const dname = days[i];
      const cell = document.createElement("div");
      const date = addDays(currentWeek, i);
      cell.innerHTML = `<strong>${dname}</strong><div class="muted">${date.getDate()} ${date.toLocaleString(undefined,{month:"short"})}</div>`;
      headerRow.appendChild(cell);
    }
    grid.appendChild(headerRow);

    const hours = hoursRange(8, 22);
    for (const h of hours) {
      const row = document.createElement("div");
      row.className = "grid-row";
      const label = document.createElement("div");
      label.className = "time-label";
      label.textContent = `${String(h).padStart(2,"0")}:00`;
      row.appendChild(label);
      for (let col=0; col<7; col++) {
        const cell = document.createElement("div");
        cell.className = "slot";
        cell.dataset.day = String(col);
        cell.dataset.hour = String(h);
        row.appendChild(cell);
      }
      grid.appendChild(row);
    }

    // Drop events into cells (approx 1-hour blocks)
    for (const {society, event, source} of items) {
      const dt = new Date(event.start);
      const ws = startOfWeek(dt);
      if (ws.getTime() !== currentWeek.getTime()) continue; // only this week

      const day = (dt.getDay()+6)%7; // Mon=0
      const hour = dt.getHours();

      const selector = `.slot[data-day="${day}"][data-hour="${hour}"]`;
      const cell = grid.querySelector(selector);
      if (!cell) continue;

      const pill = document.createElement("div");
      pill.className = "pill";
      pill.innerHTML = `<strong>${event.title}</strong><br><span class="muted">${society.name}</span><br><span class="muted">${dt.toLocaleTimeString([], {hour:"2-digit", minute:"2-digit"})} · ${event.location}</span>`;

      if (source === "manual") {
        const rm = document.createElement("button");
        rm.className = "btn tiny";
        rm.textContent = "Remove";
        rm.addEventListener("click", () => {
          const set = state.selectedEventIds;
          set.delete(event.id);
          state.selectedEventIds = set;
          renderGrid();
        });
        pill.appendChild(rm);
      } else {
        const hint = document.createElement("div");
        hint.className = "muted";
        hint.textContent = "Unfollow the society to remove auto-added events.";
        pill.appendChild(hint);
      }

      cell.appendChild(pill);
    }

    const wrapperExists = document.createElement("div");
    wrapper.appendChild(grid);
    container.appendChild(wrapper);
  }

  renderGrid();
  updateToolbar();
}
  function addDemoBanner() {
    if (document.querySelector(".demo-banner")) return;
    const banner = document.createElement("div");
    banner.className = "demo-banner";
    banner.textContent = "Demo only — no real accounts or servers. Data is saved in your browser.";
    document.body.prepend(banner);
  }

  function formatWhen(isoLocal) {
    // Render like "Mon 3 Nov, 6:00pm"
    const d = new Date(isoLocal);
    if (isNaN(d.getTime())) return isoLocal;
    const opts = { weekday: "short", day: "numeric", month: "short", hour: "2-digit", minute: "2-digit" };
    return d.toLocaleString(undefined, opts);
  }

  
  function getQueryParams() {
    const params = {};
    const q = window.location.search.substring(1).split("&").filter(Boolean);
    for (const kv of q) {
      const [k, v] = kv.split("=");
      params[decodeURIComponent(k)] = decodeURIComponent(v || "");
    }
    return params;
  }

  function initEventsPage() {
    const list = document.querySelector(".events-list");
    const params = getQueryParams();
    const filterSoc = params["society"] || null;

    function renderRows() {
      list.innerHTML = "";
      const all = [];
      for (const s of societies) {
        for (const ev of s.events) {
          all.push({society: s, event: ev});
        }
      }
      all.sort((a,b) => a.event.start.localeCompare(b.event.start));

      for (const {society, event} of all) {
        if (filterSoc && society.id !== filterSoc) continue;

        const row = document.createElement("div");
        row.className = "event-row";

        const left = document.createElement("div");
        left.className = "event-main";
        const t = document.createElement("h3");
        t.textContent = event.title;
        const meta = document.createElement("p");
        meta.className = "muted";
        meta.textContent = `${formatWhen(event.start)} — ${event.location} • ${society.name}`;
        left.append(t, meta);

        const right = document.createElement("div");
        right.className = "event-actions";

        // Follow toggle (affects all events)
        const followBtn = document.createElement("button");
        followBtn.className = "btn subtle";
        const isFollowing = state.follows.has(society.id);
        followBtn.textContent = isFollowing ? "Following ✓" : "Follow society";
        followBtn.setAttribute("aria-pressed", isFollowing ? "true" : "false");
        followBtn.addEventListener("click", () => {
          const set = state.follows;
          if (set.has(society.id)) set.delete(society.id); else set.add(society.id);
          state.follows = set;
          renderRows();
        });

        // Individual add
        const addBtn = document.createElement("button");
        addBtn.className = "btn";
        const already = isEventInCalendar(event.id);
        addBtn.textContent = already ? "In My Timetable" : "Add to My Timetable";
        addBtn.disabled = already;
        addBtn.addEventListener("click", () => {
          const set = state.selectedEventIds;
          set.add(event.id);
          state.selectedEventIds = set;
          renderRows();
        });

        right.append(followBtn, addBtn);
        row.append(left, right);
        list.appendChild(row);
      }
    }

    renderRows();
    addDemoBanner();
  }

  
  // --- Timetable Grid helpers ----------------------------------------------
  function startOfWeek(date) {
    const d = new Date(date.getFullYear(), date.getMonth(), date.getDate());
    const day = (d.getDay() + 6) % 7; // Monday=0
    d.setDate(d.getDate() - day);
    d.setHours(0,0,0,0);
    return d;
  }
  function addDays(d, n) {
    const x = new Date(d); x.setDate(x.getDate() + n); return x;
  }
  function isSameDay(a,b) {
    return a.getFullYear()===b.getFullYear() && a.getMonth()===b.getMonth() && a.getDate()===b.getDate();
  }
  function hoursRange(start=8, end=22) {
    const arr = [];
    for (let h=start; h<=end; h++) arr.push(h);
    return arr;
  }

  // --- Router ---------------------------------------------------------------
  document.addEventListener("DOMContentLoaded", () => {
  const body = document.body;
  if (body.classList.contains("profile-page")) initProfilePage();
  if (body.classList.contains("foryou-page")) initForYouPage();
  if (body.classList.contains("timetable-page")) initTimetablePage();
  if (body.classList.contains("events-page")) initEventsPage();
  attachClearDataHandlers();
  addDemoBanner();
});
})();